function letter = corresponding_letter(x)
%Convert [1,2,3,4] into [a,b,c,d]

switch x
    case 1
        letter = 'a';
    case 2
        letter = 'b';
    case 3
        letter = 'c';
    case 4
        letter = 'd';
end

end