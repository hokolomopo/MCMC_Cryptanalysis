function [ y ] = random_permut(x)
%Return a random permutation of the argument vector

y = randperm(length(x));

end

